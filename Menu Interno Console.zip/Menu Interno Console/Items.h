void ItemsMenu()
{
	MenuFunctions.Name[1] = (char*)"Life";
	MenuFunctions.Name[2] = (char*)"Money";
	MenuFunctions.Items = 2;
}