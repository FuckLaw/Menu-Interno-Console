#include <fstream>
#include <iostream>
#include <vector>
#include <cstdio>
#include <tlhelp32.h>
using namespace std;